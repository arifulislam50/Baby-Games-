# Packages

Source of truth: `Packages/manifest.json`. Unity resolves and downloads these the first time the project is opened (needs internet once).

**Verification note:** these versions were written from knowledge of the Unity 6000.0 package set. They were **not** resolved against the Unity package registry in the environment where this project was authored (no Unity Editor, registry blocked). If Package Manager reports a missing version, pick the nearest available one in Window > Package Manager.

## Declared in the manifest

| Package | Version | Why |
|---|---|---|
| `com.unity.ugui` | 2.0.0 | Canvas UI for the virtual joystick, jump button and HUD (later phases). |
| `com.unity.test-framework` | 1.4.5 | Edit Mode / Play Mode tests. |
| `com.unity.ide.visualstudio` | 2.0.22 | Visual Studio code editing and debugging. |
| `com.unity.ide.rider` | 3.0.31 | JetBrains Rider support. |

Built-in modules (ship with the editor, version 1.0.0): `ai`, `androidjni`, `animation`, `audio`, `imgui`, `jsonserialize`, `particlesystem`, `physics`, `ui`.

## Render pipeline

**Built-in Render Pipeline** (no URP/HDRP package). Reason: the smallest, fastest option for low-end phones and the simplest to keep editable. Lighting is one realtime directional light, tri-light ambient, linear fog, a solid-colour sky, and the project's own vertex-lit shader `TinyWorld/LowPolyLit`.

## Not installed (candidates for later phases, only if needed)

| Package | Possible use |
|---|---|
| `com.unity.ai.navigation` | NavMesh walking for helper animals |
| `com.unity.inputsystem` | Not needed: joystick and jump button use UGUI and legacy touch input |
| `com.unity.cinemachine` | Not needed: the follow camera will be a small custom script |

## Required software (outside the project)

| Software | Version | Notes |
|---|---|---|
| Unity Hub + Unity Editor | 6000.0 LTS (project created for 6000.0.23f1; any 6000.0.x works) | |
| Unity Android Build Support | same as editor | Install via Unity Hub: includes **OpenJDK** and **Android SDK & NDK Tools** |
| Android phone or emulator | Android 7.0 (API 24) or newer | USB debugging on |
