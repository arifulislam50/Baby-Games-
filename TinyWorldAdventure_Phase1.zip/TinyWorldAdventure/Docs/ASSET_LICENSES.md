# Third-party asset licences

Phase 1 uses **no third-party assets**. Every script, shader, material and document in this project was written for it.

Add one row per third-party asset (model, texture, sound, font, package) *before* adding the asset to the project.

| Asset | Source URL | Author | Licence | Commercial use allowed | Added on |
|---|---|---|---|---|---|
| (none) | | | | | |
