# Baby Bear — Character Design Specification

Character for **Tiny World Adventure** (3D adventure exploration game for children aged 3–5).
This is an original design. It is a specification only: the 3D model and animation files are **not yet created** (see "Status").

## 1. Concept

A cheerful, curious brown baby bear explorer. Soft, round and safe-looking: no sharp edges, no scary features, always smiling.
Silhouette test: round head with two small round ears, pear-shaped body, short legs, a small green backpack on the back.

## 2. Colour palette (flat colours, one palette for every pose and animation)

| Part | Hex | Notes |
|---|---|---|
| Main fur | `#A6693A` | Head, body, arms, legs, ears |
| Darker fur | `#7A4A28` | Foot soles, paw tips, tail |
| Muzzle / belly patch | `#F6E3C0` | Cream, oval muzzle; small belly patch |
| Inner ear | `#E8B79A` | Small circle inside each ear |
| Nose | `#3A2418` | Small, rounded triangle |
| Eye white | `#FFFFFF` | Large oval |
| Iris / pupil | `#2E2018` | Big round pupil filling most of the eye |
| Eye highlight | `#FFFFFF` | One big + one small sparkle per eye |
| Cheek blush | `#F29A8E` | Soft circles, low opacity (baked into texture) |
| Backpack | `#4FA86A` | Explorer green |
| Backpack straps / trim | `#357A4D` | Darker green |
| Backpack buckle | `#F2C94C` | Warm yellow |

## 3. Proportions

- Total height: **0.9 Unity units** (about 0.9 m), so doors, trees and fruit in later phases can be scaled against it.
- Head ≈ **45 %** of total height (chibi / toddler proportions). Body ≈ 30 %. Legs ≈ 25 %.
- Head width slightly wider than the body width. Body is pear-shaped (wider at the belly).
- Arms short, ending just below the belly line. Legs short and stubby. Feet round and slightly larger than the legs.
- Ears: small, round, set on the upper sides of the head. Ear diameter ≈ 20 % of head width.
- Tail: tiny round puff (optional bone, used in Idle/Run/Celebrate).

## 4. Face

- **Eyes:** large, glossy ovals, set wide apart, below the head's midline (cuter, younger look). Each eye ≈ 22 % of head width.
- **Muzzle:** cream oval, small, pushed slightly forward. Nose sits at the top of the muzzle.
- **Mouth:** friendly smile, a simple curve under the nose. Open "happy" mouth variant allowed for Wave and Celebrate.
- **Cheeks:** soft blush circles.
- Expressions (baked into a face texture or UV-offset): *Neutral smile*, *Blink*, *Happy open mouth*. No angry, sad or scared expressions anywhere in the game.

## 5. Backpack

- Small rounded rectangle, ≈ 30 % of body height, sitting on the upper back.
- Green body, darker green flap and straps, yellow buckle, one small side pocket.
- Separate mesh parented to the `Backpack` bone (child of `Spine`) so it follows the body and can bounce slightly during Run and Jump.
- Visible from the front as two straps over the shoulders.

## 6. Technical model specification (low-end Android)

| Item | Target | Hard limit |
|---|---|---|
| Triangles (body + backpack) | 1,200 – 2,000 | 2,500 (the import postprocessor logs a warning above this) |
| Materials | 1 shared palette material (`TinyWorld/LowPolyLit`) | 2 |
| Texture | 128×128 or 256×256 palette/face atlas, no alpha | 512×512 |
| Bones | 16 | 25 |
| Skin weights per vertex | 4 | 4 |
| Blend shapes | none | none |
| Rig type | Generic | — |
| Root motion | off (movement comes from the controller script) | — |
| Pivot | at the feet, centre of the body, facing +Z | — |
| Normals | smooth (60° angle) for the soft toy look | — |

## 7. Skeleton (16 bones)

```
Root
└─ Hips
   ├─ Spine
   │  ├─ Head
   │  │  ├─ Ear_L
   │  │  └─ Ear_R
   │  ├─ Arm_L ── Hand_L
   │  ├─ Arm_R ── Hand_R
   │  └─ Backpack
   ├─ Leg_L ── Foot_L
   ├─ Leg_R ── Foot_R
   └─ Tail
```

## 8. Required animations

All clips use the same skeleton, same scale, same proportions, 30 fps. Animation files must not change the model's look: only bone rotation / position, never scale (squash and stretch is allowed only by a small, symmetric `Spine` scale of at most ±5 % and must return to 1.0).

| Clip | Loop | Length | Description |
|---|---|---|---|
| **Idle** | yes | 2.0 s (60 f) | Gentle breathing, slow weight shift, ears twitch once, blink once. |
| **Walk** | yes | 0.8 s (24 f) | Waddle: short steps, arms swing a little, body bobs, backpack sways. |
| **Run** | yes | 0.53 s (16 f) | Bouncy fast waddle, leaning slightly forward, arms pump, ears and backpack bounce. |
| **Jump** | no | 0.7 s (21 f) | Crouch (3 f), spring up with arms raised, hold open pose in the air, soft landing squash. |
| **Wave** | no | 1.5 s (45 f) | Right arm raised and waving three times, big smile, slight head tilt. |
| **Celebrate** | no | 2.0 s (60 f) | Both arms up, two happy hops, small spin, open happy mouth. |

Planned Animator parameters (to be created in a later phase, not part of Phase 1): `Speed` (float), `Grounded` (bool), `Jump` (trigger), `Wave` (trigger), `Celebrate` (trigger).
Transitions: Idle ⇄ Walk ⇄ Run by `Speed`; any state → Jump by trigger; Jump → Idle on landing; Wave and Celebrate return to Idle when finished.

## 9. Consistency rules

1. One mesh, one rig, one palette for every animation. Do not create per-animation versions of the model.
2. Never change eye size, muzzle colour, ear size or backpack colour in any clip or expression.
3. The face always reads as friendly, including mid-motion (no frowns).
4. Scale of the model in Unity stays at (1, 1, 1).
5. New equipment (hat, held fruit) is added as separate meshes attached to bones, never baked into the body mesh.

## 10. Import pipeline (what Phase 1 set up)

Folders: `Assets/Characters/BabyBear/` (mesh + textures) and `Assets/Animations/` (clips).

File naming:

- `Assets/Characters/BabyBear/BabyBear.fbx` — mesh and skeleton (may also contain all six clips).
- `Assets/Animations/BabyBear@Idle.fbx`, `BabyBear@Walk.fbx`, `BabyBear@Run.fbx`, `BabyBear@Jump.fbx`, `BabyBear@Wave.fbx`, `BabyBear@Celebrate.fbx` — if the clips are exported as separate files.

Automatic settings (`Assets/Scripts/Editor/CharacterImportPostprocessor.cs`), applied the first time a file is imported from those folders (your later manual changes are never overwritten):

- Generic rig, materials not imported (assign from `Assets/Materials`), mesh compression Medium, not readable, no cameras / lights / blend shapes, 4 bone weights.
- Animation compression Optimal. Clips whose names contain `idle`, `walk` or `run` are set to loop.
- A warning is logged if the model has more than 2,500 triangles.

Textures (`TextureImportPostprocessor.cs`): max 1024 (UI 2048), compressed, ASTC 6x6 on Android (ASTC 4x4 for UI sprites), mipmaps on for 3D and off for UI.

## 11. Licensing

Every asset must be original or have a licence that allows commercial use (for example CC0). Record the source and licence of any third-party asset in `Docs/ASSET_LICENSES.md` before adding it. No paid or copyrighted assets are used in Phase 1.

## 12. Status

| Item | Status |
|---|---|
| This design specification | Done |
| Import pipeline (folders + postprocessors) | Done, compiles; not yet exercised with a real model |
| Baby Bear 3D model (`.fbx`) | **Not created.** Needs a modelling tool (e.g. Blender) or a procedural mesh script in a later phase. |
| Six animation clips | **Not created.** Same as above. |
