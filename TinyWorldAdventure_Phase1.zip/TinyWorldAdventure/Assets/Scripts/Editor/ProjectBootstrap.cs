using System.IO;
using UnityEditor;
#if UNITY_2021_2_OR_NEWER
using UnityEditor.Build;
#endif
using UnityEngine;
using UnityEngine.Rendering;

namespace TinyWorld.EditorTools
{
    /// <summary>
    /// One-click project setup for Tiny World Adventure.
    /// Applies Android / low-end mobile Player settings, makes sure the folder structure exists,
    /// and switches the active build target to Android. Runs once automatically the first time the
    /// project is opened, and any time from the "Tiny World" menu.
    /// </summary>
    [InitializeOnLoad]
    public static class ProjectBootstrap
    {
        public const string CompanyName = "TinyWorld Studio";
        public const string ProductName = "Tiny World Adventure";
        public const string AndroidPackageId = "com.tinyworld.adventure";
        public const string VersionName = "0.1.0";
        public const string ForestScenePath = "Assets/Scenes/ForestWorld.unity";

        public static readonly string[] RequiredFolders =
        {
            "Assets/Scripts/Player",
            "Assets/Scripts/Camera",
            "Assets/Scripts/Missions",
            "Assets/Scripts/Animals",
            "Assets/Scripts/UI",
            "Assets/Scripts/Managers",
            "Assets/Scripts/Editor",
            "Assets/Characters",
            "Assets/Animations",
            "Assets/Environment",
            "Assets/Materials",
            "Assets/Prefabs",
            "Assets/Scenes",
            "Assets/Audio",
            "Assets/UI",
        };

        private static string AppliedPrefKey
        {
            get { return "TinyWorld.Phase1.SettingsApplied:" + Application.dataPath; }
        }

        static ProjectBootstrap()
        {
            if (Application.isBatchMode || EditorPrefs.GetBool(AppliedPrefKey, false))
            {
                return;
            }

            EditorApplication.delayCall += () =>
            {
                ApplyAll(false);
                EditorPrefs.SetBool(AppliedPrefKey, true);
            };
        }

        [MenuItem("Tiny World/Apply Android Mobile Settings")]
        private static void ApplyFromMenu()
        {
            ApplyAll(true);
        }

        [MenuItem("Tiny World/Create Folder Structure")]
        private static void CreateFoldersFromMenu()
        {
            EnsureFolders();
            Debug.Log("[TinyWorld] Folder structure checked.");
        }

        /// <summary>Applies every Phase 1 project setting. Can be called from batch mode.</summary>
        public static void ApplyAll(bool verbose)
        {
            EnsureFolders();
            ApplyPlayerSettings();
            ApplyBuildSettings();
            AssetDatabase.SaveAssets();

            if (verbose)
            {
                Debug.Log("[TinyWorld] Android mobile settings applied.");
            }

            SwitchToAndroid(verbose);
        }

        public static void EnsureFolders()
        {
            foreach (string folder in RequiredFolders)
            {
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
            }

            AssetDatabase.Refresh();
        }

        private static void ApplyPlayerSettings()
        {
            PlayerSettings.companyName = CompanyName;
            PlayerSettings.productName = ProductName;
            PlayerSettings.bundleVersion = VersionName;

            // Orientation: landscape only (left + right).
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;

            // Rendering: Gamma colour space and OpenGL ES 3 are the cheapest, most compatible choice
            // for low-end phones. Linear colour space and Vulkan cost more and are less stable on old GPUs.
            PlayerSettings.colorSpace = ColorSpace.Gamma;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.gpuSkinning = true;
            PlayerSettings.MTRendering = true;
            PlayerSettings.stripEngineCode = true;

            // Android.
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.Android.preferredInstallLocation = AndroidPreferredInstallLocation.Auto;

#if UNITY_2021_2_OR_NEWER
            NamedBuildTarget android = NamedBuildTarget.Android;
            PlayerSettings.SetApplicationIdentifier(android, AndroidPackageId);
            PlayerSettings.SetScriptingBackend(android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(android, ManagedStrippingLevel.Low);
            PlayerSettings.SetIl2CppCompilerConfiguration(android, Il2CppCompilerConfiguration.Release);
#else
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, AndroidPackageId);
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Low);
            PlayerSettings.SetIl2CppCompilerConfiguration(BuildTargetGroup.Android, Il2CppCompilerConfiguration.Release);
#endif

            // No stack traces for plain logs: saves CPU on device.
            PlayerSettings.SetStackTraceLogType(LogType.Log, StackTraceLogType.None);
            PlayerSettings.SetStackTraceLogType(LogType.Warning, StackTraceLogType.None);
        }

        private static void ApplyBuildSettings()
        {
            EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;
            EditorUserBuildSettings.buildAppBundle = false; // APK for easy device testing. Turn on for Google Play.

            if (File.Exists(ForestScenePath))
            {
                EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ForestScenePath, true) };
            }
        }

        private static void SwitchToAndroid(bool verbose)
        {
            if (EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android)
            {
                return;
            }

            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogWarning("[TinyWorld] Android Build Support is not installed for this Unity version. " +
                                 "Install it from Unity Hub (Installs > Add modules > Android Build Support, " +
                                 "including OpenJDK and Android SDK & NDK Tools), then run Tiny World > Apply Android Mobile Settings.");
                return;
            }

            if (verbose)
            {
                Debug.Log("[TinyWorld] Switching active build target to Android...");
            }

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
        }
    }
}
