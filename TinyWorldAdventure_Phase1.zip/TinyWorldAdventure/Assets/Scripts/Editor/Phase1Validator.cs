using System.Collections.Generic;
using System.IO;
using UnityEditor;
#if UNITY_2021_2_OR_NEWER
using UnityEditor.Build;
#endif
using UnityEngine;

namespace TinyWorld.EditorTools
{
    /// <summary>
    /// Checks that the Phase 1 setup is correct on THIS machine, inside the real Unity Editor.
    /// Menu: Tiny World > Validate Phase 1 Setup.
    /// Batch mode: Unity -batchmode -quit -projectPath . -executeMethod TinyWorld.EditorTools.Phase1Validator.RunBatch
    /// </summary>
    public static class Phase1Validator
    {
        [MenuItem("Tiny World/Validate Phase 1 Setup")]
        private static void RunFromMenu()
        {
            Run();
        }

        /// <summary>Batch-mode entry point. Exits with code 1 if any check fails.</summary>
        public static void RunBatch()
        {
            EditorApplication.Exit(Run() ? 0 : 1);
        }

        /// <summary>Runs every check, logs one line per check, returns true if all passed.</summary>
        public static bool Run()
        {
            List<string> failures = new List<string>();
            List<string> passes = new List<string>();

            Check(EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android,
                "Active build target is Android", passes, failures);

            foreach (string folder in ProjectBootstrap.RequiredFolders)
            {
                Check(Directory.Exists(folder), "Folder exists: " + folder, passes, failures);
            }

            Check(File.Exists(ProjectBootstrap.ForestScenePath),
                "Scene exists: " + ProjectBootstrap.ForestScenePath, passes, failures);

            bool inBuild = false;
            foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
            {
                if (scene.enabled && scene.path == ProjectBootstrap.ForestScenePath)
                {
                    inBuild = true;
                }
            }

            Check(inBuild, "ForestWorld is enabled in Build Settings", passes, failures);

#if UNITY_2021_2_OR_NEWER
            Check(PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android) == ProjectBootstrap.AndroidPackageId,
                "Android package id is " + ProjectBootstrap.AndroidPackageId, passes, failures);
            Check(PlayerSettings.GetScriptingBackend(NamedBuildTarget.Android) == ScriptingImplementation.IL2CPP,
                "Scripting backend is IL2CPP", passes, failures);
#else
            Check(PlayerSettings.GetApplicationIdentifier(BuildTargetGroup.Android) == ProjectBootstrap.AndroidPackageId,
                "Android package id is " + ProjectBootstrap.AndroidPackageId, passes, failures);
            Check(PlayerSettings.GetScriptingBackend(BuildTargetGroup.Android) == ScriptingImplementation.IL2CPP,
                "Scripting backend is IL2CPP", passes, failures);
#endif

            Check((PlayerSettings.Android.targetArchitectures & AndroidArchitecture.ARM64) != 0,
                "ARM64 is enabled", passes, failures);
            Check(PlayerSettings.Android.minSdkVersion >= AndroidSdkVersions.AndroidApiLevel23,
                "Minimum Android API level is 23 or higher", passes, failures);
            Check(PlayerSettings.colorSpace == ColorSpace.Gamma,
                "Colour space is Gamma (cheaper on low-end phones)", passes, failures);
            Check(!PlayerSettings.allowedAutorotateToPortrait && PlayerSettings.allowedAutorotateToLandscapeLeft,
                "Orientation is landscape only", passes, failures);

            foreach (string line in passes)
            {
                Debug.Log("[TinyWorld][PASS] " + line);
            }

            foreach (string line in failures)
            {
                Debug.LogError("[TinyWorld][FAIL] " + line);
            }

            Debug.Log("[TinyWorld] Phase 1 validation: " + passes.Count + " passed, " + failures.Count + " failed." +
                      (failures.Count > 0 ? " Run Tiny World > Apply Android Mobile Settings, then validate again." : ""));

            return failures.Count == 0;
        }

        private static void Check(bool ok, string label, List<string> passes, List<string> failures)
        {
            (ok ? passes : failures).Add(label);
        }
    }
}
