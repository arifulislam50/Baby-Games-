using UnityEditor;
using UnityEngine;

namespace TinyWorld.EditorTools
{
    /// <summary>
    /// Import pipeline for the Baby Bear and other characters / animation files.
    /// Applies mobile-friendly model and animation settings the first time a file is imported
    /// from Assets/Characters or Assets/Animations. Settings you change by hand afterwards are kept
    /// (the rules only run while the file has no .meta settings yet).
    ///
    /// File naming conventions (see Docs/CharacterDesign.md):
    ///   Assets/Characters/BabyBear/BabyBear.fbx            mesh + skeleton
    ///   Assets/Animations/BabyBear@Idle.fbx (etc.)         one animation per file, or all clips in BabyBear.fbx
    /// Clip names that contain "idle", "walk" or "run" are set to loop.
    /// </summary>
    public class CharacterImportPostprocessor : AssetPostprocessor
    {
        private const string CharactersRoot = "Assets/Characters/";
        private const string AnimationsRoot = "Assets/Animations/";

        private static bool IsCharacterAsset(string path)
        {
            return path.StartsWith(CharactersRoot) || path.StartsWith(AnimationsRoot);
        }

        private static bool ShouldLoop(string clipName)
        {
            string n = clipName.ToLowerInvariant();
            return n.Contains("idle") || n.Contains("walk") || n.Contains("run");
        }

        private void OnPreprocessModel()
        {
            if (!IsCharacterAsset(assetPath))
            {
                return;
            }

            ModelImporter importer = (ModelImporter)assetImporter;
            if (!importer.importSettingsMissing)
            {
                return;
            }

            // Scale and geometry.
            importer.globalScale = 1f;
            importer.useFileScale = true;
            importer.meshCompression = ModelImporterMeshCompression.Medium;
            importer.isReadable = false;
            importer.optimizeMeshPolygons = true;
            importer.optimizeMeshVertices = true;
            importer.weldVertices = true;
            importer.generateSecondaryUV = false;
            importer.importBlendShapes = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.importVisibility = false;
            importer.importNormals = ModelImporterNormals.Calculate;
            importer.normalSmoothingAngle = 60f;
            importer.skinWeights = ModelImporterSkinWeights.Standard; // max 4 bones per vertex

            // Materials are assigned from Assets/Materials so every character shares the same palette material.
            importer.materialImportMode = ModelImporterMaterialImportMode.None;

            // Rig: Generic keeps the skeleton cheap. Optimize Game Objects stays off so props
            // (backpack, held items) can be attached to bones.
            importer.animationType = ModelImporterAnimationType.Generic;
            importer.optimizeGameObjects = false;

            // Animation.
            importer.animationCompression = ModelImporterAnimationCompression.Optimal;
            importer.animationRotationError = 0.5f;
            importer.animationPositionError = 0.5f;
            importer.animationScaleError = 0.5f;
        }

        private void OnPreprocessAnimation()
        {
            if (!IsCharacterAsset(assetPath))
            {
                return;
            }

            ModelImporter importer = (ModelImporter)assetImporter;
            if (!importer.importSettingsMissing)
            {
                return;
            }

            ModelImporterClipAnimation[] clips = importer.defaultClipAnimations;
            if (clips == null || clips.Length == 0)
            {
                return;
            }

            for (int i = 0; i < clips.Length; i++)
            {
                bool loop = ShouldLoop(clips[i].name);
                clips[i].loopTime = loop;
                clips[i].loopPose = loop;
            }

            importer.clipAnimations = clips;
        }

        private void OnPostprocessModel(GameObject root)
        {
            if (!IsCharacterAsset(assetPath))
            {
                return;
            }

            int triangles = 0;
            foreach (MeshFilter filter in root.GetComponentsInChildren<MeshFilter>(true))
            {
                if (filter.sharedMesh != null)
                {
                    triangles += filter.sharedMesh.triangles.Length / 3;
                }
            }

            foreach (SkinnedMeshRenderer skinned in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (skinned.sharedMesh != null)
                {
                    triangles += skinned.sharedMesh.triangles.Length / 3;
                }
            }

            if (triangles > MaxCharacterTriangles)
            {
                Debug.LogWarning("[TinyWorld] " + assetPath + " has " + triangles + " triangles. " +
                                 "Budget for characters is " + MaxCharacterTriangles + " for low-end phones.");
            }
        }

        /// <summary>Triangle budget for one on-screen character.</summary>
        public const int MaxCharacterTriangles = 2500;
    }
}
