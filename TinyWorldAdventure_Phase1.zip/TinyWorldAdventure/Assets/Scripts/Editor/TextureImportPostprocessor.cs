using UnityEditor;
using UnityEngine;

namespace TinyWorld.EditorTools
{
    /// <summary>
    /// Mobile texture rules. The first time a texture is imported from one of the game's art folders,
    /// it gets size limits and ASTC compression for Android. Settings changed by hand afterwards are kept.
    /// </summary>
    public class TextureImportPostprocessor : AssetPostprocessor
    {
        private const string UiRoot = "Assets/UI/";

        private static readonly string[] ArtRoots =
        {
            "Assets/Characters/",
            "Assets/Environment/",
            "Assets/Materials/",
            "Assets/UI/",
        };

        private static bool IsArtAsset(string path)
        {
            foreach (string root in ArtRoots)
            {
                if (path.StartsWith(root))
                {
                    return true;
                }
            }

            return false;
        }

        private void OnPreprocessTexture()
        {
            if (!IsArtAsset(assetPath))
            {
                return;
            }

            TextureImporter importer = (TextureImporter)assetImporter;
            if (!importer.importSettingsMissing)
            {
                return;
            }

            bool isUi = assetPath.StartsWith(UiRoot);

            importer.maxTextureSize = isUi ? 2048 : 1024;
            importer.mipmapEnabled = !isUi;
            importer.isReadable = false;
            importer.crunchedCompression = false;
            importer.textureCompression = TextureImporterCompression.Compressed;

            if (isUi)
            {
                importer.textureType = TextureImporterType.Sprite;
            }

            // ASTC is supported by every OpenGL ES 3.0+ GPU used by phones from the last several years.
            // 6x6 keeps flat cartoon colours clean at a small size; UI uses 4x4 for crisp edges.
            TextureImporterPlatformSettings android = importer.GetPlatformTextureSettings("Android");
            android.overridden = true;
            android.maxTextureSize = importer.maxTextureSize;
            android.format = isUi ? TextureImporterFormat.ASTC_4x4 : TextureImporterFormat.ASTC_6x6;
            android.textureCompression = TextureImporterCompression.Compressed;
            importer.SetPlatformTextureSettings(android);
        }
    }
}
