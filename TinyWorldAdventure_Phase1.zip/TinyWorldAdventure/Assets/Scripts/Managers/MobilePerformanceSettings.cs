using UnityEngine;

namespace TinyWorld.Managers
{
    /// <summary>
    /// Applies runtime settings that keep the game smooth and cool on low-end Android phones.
    /// Lives on the "Managers" object in the ForestWorld scene.
    /// </summary>
    [DisallowMultipleComponent]
    public class MobilePerformanceSettings : MonoBehaviour
    {
        [Header("Frame rate")]
        [Tooltip("30 saves battery and heat on low-end phones. Raise to 60 for faster devices.")]
        [SerializeField, Range(20, 60)] private int targetFrameRate = 30;

        [Header("Resolution")]
        [Tooltip("If the screen's short side is larger than this, the game renders at this height and the result is upscaled. 0 = off.")]
        [SerializeField] private int maxRenderShortSide = 720;

        [Header("Device")]
        [SerializeField] private bool keepScreenAwake = true;
        [SerializeField] private bool landscapeOnly = true;

        private void Awake()
        {
            Apply();
        }

        /// <summary>Applies all settings. Safe to call more than once.</summary>
        public void Apply()
        {
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = targetFrameRate;

            if (keepScreenAwake)
            {
                Screen.sleepTimeout = SleepTimeout.NeverSleep;
            }

            if (landscapeOnly)
            {
                Screen.autorotateToPortrait = false;
                Screen.autorotateToPortraitUpsideDown = false;
                Screen.autorotateToLandscapeLeft = true;
                Screen.autorotateToLandscapeRight = true;
                Screen.orientation = ScreenOrientation.AutoRotation;
            }

            Input.multiTouchEnabled = true;
            ApplyResolutionCap();
        }

        private void ApplyResolutionCap()
        {
#if !UNITY_EDITOR
            if (maxRenderShortSide <= 0)
            {
                return;
            }

            int shortSide = Mathf.Min(Screen.width, Screen.height);
            if (shortSide <= maxRenderShortSide)
            {
                return;
            }

            float scale = maxRenderShortSide / (float)shortSide;
            int width = Mathf.RoundToInt(Screen.width * scale);
            int height = Mathf.RoundToInt(Screen.height * scale);
            Screen.SetResolution(width, height, true);
#endif
        }
    }
}
