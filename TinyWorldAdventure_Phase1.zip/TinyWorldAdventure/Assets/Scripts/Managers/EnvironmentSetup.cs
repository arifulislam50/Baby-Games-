using UnityEngine;
using UnityEngine.Rendering;

namespace TinyWorld.Managers
{
    /// <summary>
    /// Mobile-friendly lighting for the forest: one realtime sun with hard shadows,
    /// cheap tri-light ambient, linear fog and a solid-colour sky (no skybox cost).
    /// Runs in the editor too, so changing values in the Inspector updates the Scene view.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public class EnvironmentSetup : MonoBehaviour
    {
        [Header("Sun")]
        [SerializeField] private Light sun;
        [SerializeField] private Color sunColor = new Color(1f, 0.957f, 0.839f, 1f);
        [SerializeField, Range(0f, 2f)] private float sunIntensity = 1.1f;
        [SerializeField] private LightShadows sunShadows = LightShadows.Hard;
        [Tooltip("How far from the camera shadows are drawn. Smaller = faster.")]
        [SerializeField, Range(5f, 80f)] private float shadowDistance = 25f;

        [Header("Ambient (tri-light is cheap and soft)")]
        [SerializeField] private Color ambientSky = new Color(0.70f, 0.85f, 1.00f, 1f);
        [SerializeField] private Color ambientEquator = new Color(0.62f, 0.72f, 0.58f, 1f);
        [SerializeField] private Color ambientGround = new Color(0.38f, 0.40f, 0.30f, 1f);

        [Header("Fog")]
        [SerializeField] private bool fogEnabled = true;
        [SerializeField] private Color fogColor = new Color(0.78f, 0.90f, 0.96f, 1f);
        [SerializeField] private float fogStart = 35f;
        [SerializeField] private float fogEnd = 95f;

        [Header("Sky")]
        [SerializeField] private Camera targetCamera;
        [SerializeField] private Color skyColor = new Color(0.62f, 0.82f, 0.95f, 1f);

        private void OnEnable()
        {
            Apply();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (isActiveAndEnabled)
            {
                Apply();
            }
        }
#endif

        /// <summary>Pushes all values into RenderSettings, the sun and the camera.</summary>
        public void Apply()
        {
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = ambientSky;
            RenderSettings.ambientEquatorColor = ambientEquator;
            RenderSettings.ambientGroundColor = ambientGround;

            RenderSettings.fog = fogEnabled;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = fogColor;
            RenderSettings.fogStartDistance = fogStart;
            RenderSettings.fogEndDistance = Mathf.Max(fogEnd, fogStart + 1f);

            if (sun != null)
            {
                sun.type = LightType.Directional;
                sun.color = sunColor;
                sun.intensity = sunIntensity;
                sun.shadows = sunShadows;
                RenderSettings.sun = sun;
            }

            if (Application.isPlaying)
            {
                QualitySettings.shadowDistance = shadowDistance;
            }

            Camera cam = targetCamera != null ? targetCamera : Camera.main;
            if (cam != null)
            {
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = skyColor;
            }
        }
    }
}
