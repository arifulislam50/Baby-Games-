// Tiny World Adventure - cheap low-poly shader for the built-in render pipeline.
// One pass, per-vertex lighting (half-lambert sun + spherical-harmonics ambient), linear fog.
// No per-pixel lights, no normal maps, no specular: made for low-end Android GPUs.
// Shadows are CAST via the fallback shader; this shader does not RECEIVE shadows (saves a lot of fill-rate).
Shader "TinyWorld/LowPolyLit"
{
    Properties
    {
        _Color ("Tint", Color) = (1,1,1,1)
        _MainTex ("Albedo (optional)", 2D) = "white" {}
        _ShadeStrength ("Shade Strength", Range(0,1)) = 0.6
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        LOD 100

        Pass
        {
            Tags { "LightMode"="ForwardBase" }

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #pragma target 2.0

            #include "UnityCG.cginc"
            #include "Lighting.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;
            fixed4 _Color;
            half _ShadeStrength;

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float2 uv : TEXCOORD0;
                half3 light : TEXCOORD1;
                UNITY_FOG_COORDS(2)
            };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);

                half3 n = UnityObjectToWorldNormal(v.normal);
                half h = dot(n, normalize(_WorldSpaceLightPos0.xyz)) * 0.5h + 0.5h;
                h *= h;
                half3 lit = ShadeSH9(half4(n, 1.0h)) + _LightColor0.rgb * h;
                o.light = lerp(half3(1.0h, 1.0h, 1.0h), saturate(lit), _ShadeStrength);

                UNITY_TRANSFER_FOG(o, o.pos);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                fixed4 col = tex2D(_MainTex, i.uv) * _Color;
                col.rgb *= i.light;
                UNITY_APPLY_FOG(i.fogCoord, col);
                col.a = 1;
                return col;
            }
            ENDCG
        }
    }

    // Provides the ShadowCaster and depth passes so objects still cast shadows.
    Fallback "Mobile/VertexLit"
}
