# Tiny World Adventure

A 3D third-person adventure exploration game for children aged 3–5, for Android.
Play as a cute Baby Bear explorer: walk, run and jump through a cartoon forest, collect fruits and golden stars, help animals, complete simple missions and unlock new worlds.

**Current state: Phase 1 (project setup) — complete, with the verification limits listed below.**
Gameplay (player, camera, joystick, missions, animals) is Phase 2 and later and is **not built yet**.

## Requirements

- **Unity 6 LTS (6000.0.x)** via Unity Hub. Project created for `6000.0.23f1`.
- Unity Hub module **Android Build Support**, including **OpenJDK** and **Android SDK & NDK Tools**.
- An Android device (Android 7.0 / API 24+) with USB debugging, or an Android emulator.
- Internet on first open (Unity downloads the packages listed in `Docs/PACKAGES.md`).

## Open the project

1. Unity Hub > **Add** > select this folder (`TinyWorldAdventure`, the one containing `Assets/` and `ProjectSettings/`).
2. Open with Unity 6000.0.x. Accept the prompt to continue if the editor patch version is different from `6000.0.23f1`.
3. On first open the project **applies its Android settings automatically** (package id, IL2CPP, ARMv7 + ARM64, landscape, Gamma colour space, OpenGL ES 3, build target Android). Unity will reimport once when switching to Android.
4. Open `Assets/Scenes/ForestWorld.unity`.
5. Menu **Tiny World > Validate Phase 1 Setup** and check the Console: every line should say `[PASS]`.

If the automatic step did not run, use **Tiny World > Apply Android Mobile Settings**.

## Build an APK

1. **File > Build Settings**: platform Android, `ForestWorld` ticked in *Scenes In Build*.
2. Connect the phone, **Build And Run** (or **Build** to produce an `.apk`).
3. For Google Play, tick *Build App Bundle (Google Play)* and set up a keystore in **Project Settings > Player > Publishing Settings**. The Android package id is `com.tinyworld.adventure`; change it in Player Settings and in `ProjectBootstrap.cs` (`AndroidPackageId`) if you publish under your own name.

## Folder structure

```
Assets/
  Scripts/
    Player/      (Phase 2: bear controller, jump)
    Camera/      (Phase 2: third-person follow camera)
    Missions/    (later)
    Animals/     (later)
    UI/          (Phase 2: virtual joystick, jump button, HUD)
    Managers/    MobilePerformanceSettings.cs, EnvironmentSetup.cs
    Editor/      ProjectBootstrap.cs, Phase1Validator.cs,
                 CharacterImportPostprocessor.cs, TextureImportPostprocessor.cs
  Characters/BabyBear/   (model goes here; see Docs/CharacterDesign.md)
  Animations/            (Idle, Walk, Run, Jump, Wave, Celebrate)
  Environment/
  Materials/             4 materials + Shaders/LowPolyLit.shader
  Prefabs/
  Scenes/                ForestWorld.unity
  Audio/
  UI/
Docs/        CharacterDesign.md, PACKAGES.md, ASSET_LICENSES.md, FILE_RECORD.md, PHASE1_REPORT.md
Tools/       Python scripts that generated the scene/materials/settings and verify the project (optional)
Packages/    manifest.json
ProjectSettings/
```

`Scripts/Editor` is an addition to the requested structure: Unity only compiles editor tools that live in a folder named `Editor`.

## What the ForestWorld scene contains

- **Main Camera** (solid sky colour, no HDR, no MSAA) and **Sun** (one realtime directional light, hard shadows).
- **Managers**: `MobilePerformanceSettings` (30 fps, no vsync, render-resolution cap, landscape, screen stays awake) and `EnvironmentSetup` (tri-light ambient, linear fog, sun and sky settings; also updates the Scene view while you edit).
- **PlayerSpawn**: empty marker where the Baby Bear will be placed in Phase 2.
- **Environment**: ground, 16 placeholder trees and 8 rocks built from Unity primitives (simple colliders, static batching). These are temporary stand-ins so the scene has scale and lighting to judge; they are replaced by low-poly models later.

## Performance rules for this project

- Low-poly models: characters under 2,500 triangles, props much less.
- Textures: max 1024 px (UI 2048), ASTC compression on Android (applied automatically on import).
- Lighting: one realtime directional light, no baked GI, hard shadows, shadow distance 25.
- Shader: `TinyWorld/LowPolyLit` (per-vertex lighting, fog, no per-pixel lights).
- Physics: primitive colliders only, fixed timestep 1/30 s.
- Rendering: Built-in pipeline, Gamma colour space, OpenGL ES 3, no anti-aliasing.

## Verification status (read this)

The environment where Phase 1 was authored had **no Unity Editor**. The project has **never been opened in Unity**. What was and was not checked:

| Checked | How |
|---|---|
| All 6 C# files compile | Compiled with Roslyn against Unity's `UnityEngine.dll` / `UnityEditor.dll` **2020.2** reference assemblies. The `#if UNITY_2021_2_OR_NEWER` branches (the Unity 6 `NamedBuildTarget` calls) could **not** be compiled and are unchecked. |
| Scene / material / settings files are well-formed | A script parsed every YAML file and verified: all `fileID` links resolve, every script/shader/material GUID resolves to a `.meta`, GameObject ⇄ component ⇄ parent links agree, serialized field names exist in the C# classes. A deliberate-corruption test confirmed the script detects such faults. |
| Opens and renders in Unity 6, shows no Console errors | **Not tested.** |
| Shader compiles on a device | **Not tested.** |
| Android build, install and run | **Not tested.** |
| Package versions resolve | **Not tested** (registry not reachable). |
| `ProjectSettings.asset` | Hand-written and minimal. Unity fills in the rest; the `ProjectBootstrap` script sets every important value through the official API on first open. |

Run **Tiny World > Validate Phase 1 Setup** after opening the project, and tell me the Console output if anything fails.

## Third-party assets and licences

None. All scripts, the shader, materials and docs are original to this project. Record any future third-party asset in `Docs/ASSET_LICENSES.md`.
