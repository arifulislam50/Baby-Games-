#!/usr/bin/env python3
"""Generates the non-C# Unity project files for Tiny World Adventure (Phase 1):
folders, ProjectSettings, Packages, materials, the ForestWorld scene and every .meta file.
GUIDs are deterministic (md5 of the asset path) so re-running never changes references."""
import hashlib
import math
import os
import random
import sys

ROOT = sys.argv[1]


def guid(path):
    return hashlib.md5(("TinyWorldAdventure:" + path).encode()).hexdigest()


def write(rel, text):
    full = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", newline="\n") as f:
        f.write(text)


# --------------------------------------------------------------------------- folders
FOLDERS = [
    "Assets/Scripts", "Assets/Scripts/Player", "Assets/Scripts/Camera", "Assets/Scripts/Missions",
    "Assets/Scripts/Animals", "Assets/Scripts/UI", "Assets/Scripts/Managers", "Assets/Scripts/Editor",
    "Assets/Characters", "Assets/Characters/BabyBear", "Assets/Animations", "Assets/Environment",
    "Assets/Materials", "Assets/Materials/Shaders", "Assets/Prefabs", "Assets/Scenes", "Assets/Audio",
    "Assets/UI", "Packages", "ProjectSettings",
]
for d in FOLDERS:
    os.makedirs(os.path.join(ROOT, d), exist_ok=True)

# keep-files so empty folders survive zip/git (Unity ignores files starting with '.')
for d in ["Assets/Scripts/Player", "Assets/Scripts/Camera", "Assets/Scripts/Missions", "Assets/Scripts/Animals",
          "Assets/Scripts/UI", "Assets/Characters/BabyBear", "Assets/Animations", "Assets/Environment",
          "Assets/Prefabs", "Assets/Audio", "Assets/UI"]:
    write(d + "/.gitkeep", "")

# --------------------------------------------------------------------------- materials
SHADER_PATH = "Assets/Materials/Shaders/LowPolyLit.shader"
SHADER_GUID = guid(SHADER_PATH)

MATERIALS = {
    "Ground_Grass": (0.45, 0.78, 0.35),
    "Trunk_Brown": (0.47, 0.31, 0.18),
    "Foliage_Green": (0.30, 0.66, 0.31),
    "Rock_Gray": (0.62, 0.64, 0.67),
}


def material_yaml(name, rgb):
    r, g, b = rgb
    return f"""%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!21 &2100000
Material:
  serializedVersion: 8
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_Name: {name}
  m_Shader: {{fileID: 4800000, guid: {SHADER_GUID}, type: 3}}
  m_Parent: {{fileID: 0}}
  m_ModifiedSerializedProperties: 0
  m_ValidKeywords: []
  m_InvalidKeywords: []
  m_LightmapFlags: 4
  m_EnableInstancingVariants: 0
  m_DoubleSidedGI: 0
  m_CustomRenderQueue: -1
  stringTagMap: {{}}
  disabledShaderPasses: []
  m_LockedProperties:
  m_SavedProperties:
    serializedVersion: 3
    m_TexEnvs:
    - _MainTex:
        m_Texture: {{fileID: 0}}
        m_Scale: {{x: 1, y: 1}}
        m_Offset: {{x: 0, y: 0}}
    m_Ints: []
    m_Floats:
    - _ShadeStrength: 0.6
    m_Colors:
    - _Color: {{r: {r}, g: {g}, b: {b}, a: 1}}
  m_BuildTextureStacks: []
"""


MAT_GUID = {}
for n, rgb in MATERIALS.items():
    p = f"Assets/Materials/{n}.mat"
    MAT_GUID[n] = guid(p)
    write(p, material_yaml(n, rgb))

# --------------------------------------------------------------------------- scene
SCRIPT_PERF = "Assets/Scripts/Managers/MobilePerformanceSettings.cs"
SCRIPT_ENV = "Assets/Scripts/Managers/EnvironmentSetup.cs"

_next = [1000]


def nid():
    _next[0] += 1
    return _next[0]


docs = []  # list of (classID, fileID, body)


def quat_euler(x, y, z):
    x, y, z = [math.radians(a) * 0.5 for a in (x, y, z)]
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    # Unity order: Z, X, Y
    qw = cx * cy * cz + sx * sy * sz
    qx = sx * cy * cz + cx * sy * sz
    qy = cx * sy * cz - sx * cy * sz
    qz = cx * cy * sz - sx * sy * cz
    return (qx, qy, qz, qw)


class GO:
    def __init__(self, name, pos=(0, 0, 0), euler=(0, 0, 0), scale=(1, 1, 1), parent=None, tag="Untagged",
                 layer=0, static=0):
        self.id = nid()
        self.tr = nid()
        self.name, self.pos, self.euler, self.scale = name, pos, euler, scale
        self.parent, self.tag, self.layer, self.static = parent, tag, layer, static
        self.components = [self.tr]
        self.children = []
        if parent:
            parent.children.append(self)
        self.extra = []

    def add(self, class_id, body_fn):
        cid = nid()
        self.components.append(cid)
        self.extra.append((class_id, cid, body_fn))
        return cid

    def emit(self):
        comps = "\n".join(f"  - component: {{fileID: {c}}}" for c in self.components)
        docs.append((1, self.id, f"""GameObject:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  serializedVersion: 6
  m_Component:
{comps}
  m_Layer: {self.layer}
  m_Name: {self.name}
  m_TagString: {self.tag}
  m_Icon: {{fileID: 0}}
  m_NavMeshLayer: 0
  m_StaticEditorFlags: {self.static}
  m_IsActive: 1"""))
        qx, qy, qz, qw = quat_euler(*self.euler)
        kids = "\n".join(f"  - {{fileID: {c.tr}}}" for c in self.children)
        kids = ("\n" + kids) if kids else " []"
        father = self.parent.tr if self.parent else 0
        docs.append((4, self.tr, f"""Transform:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {self.id}}}
  serializedVersion: 2
  m_LocalRotation: {{x: {qx:.6f}, y: {qy:.6f}, z: {qz:.6f}, w: {qw:.6f}}}
  m_LocalPosition: {{x: {self.pos[0]}, y: {self.pos[1]}, z: {self.pos[2]}}}
  m_LocalScale: {{x: {self.scale[0]}, y: {self.scale[1]}, z: {self.scale[2]}}}
  m_Children:{kids}
  m_Father: {{fileID: {father}}}
  m_LocalEulerAnglesHint: {{x: {self.euler[0]}, y: {self.euler[1]}, z: {self.euler[2]}}}"""))
        for class_id, cid, body_fn in self.extra:
            docs.append((class_id, cid, body_fn(self)))


HEAD = """  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  m_GameObject: {fileID: %d}"""

PRIMS = {"cube": 10202, "cylinder": 10206, "sphere": 10207}


def add_mesh(go, prim, mat):
    go.add(33, lambda g: f"""MeshFilter:
{HEAD % g.id}
  m_Mesh: {{fileID: {PRIMS[prim]}, guid: 0000000000000000e000000000000000, type: 0}}""")
    go.add(23, lambda g: f"""MeshRenderer:
{HEAD % g.id}
  m_Enabled: 1
  m_CastShadows: 1
  m_ReceiveShadows: 1
  m_DynamicOccludee: 1
  m_StaticShadowCaster: 0
  m_MotionVectors: 0
  m_LightProbeUsage: 0
  m_ReflectionProbeUsage: 0
  m_RayTracingMode: 2
  m_RayTraceProcedural: 0
  m_RenderingLayerMask: 1
  m_RendererPriority: 0
  m_Materials:
  - {{fileID: 2100000, guid: {MAT_GUID[mat]}, type: 2}}
  m_StaticBatchInfo:
    firstSubMesh: 0
    subMeshCount: 0
  m_StaticBatchRoot: {{fileID: 0}}
  m_ProbeAnchor: {{fileID: 0}}
  m_LightProbeVolumeOverride: {{fileID: 0}}
  m_ScaleInLightmap: 1
  m_ReceiveGI: 1
  m_PreserveUVs: 0
  m_IgnoreNormalsForChartDetection: 0
  m_ImportantGI: 0
  m_StitchLightmapSeams: 1
  m_SelectedEditorRenderState: 3
  m_MinimumChartSize: 4
  m_AutoUVMaxDistance: 0.5
  m_AutoUVMaxAngle: 89
  m_LightmapParameters: {{fileID: 0}}
  m_SortingLayerID: 0
  m_SortingLayer: 0
  m_SortingOrder: 0""")


def add_box(go, size=(1, 1, 1), center=(0, 0, 0)):
    go.add(65, lambda g: f"""BoxCollider:
{HEAD % g.id}
  m_Material: {{fileID: 0}}
  m_IncludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_ExcludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_LayerOverridePriority: 0
  m_IsTrigger: 0
  m_ProvidesContacts: 0
  m_Enabled: 1
  serializedVersion: 3
  m_Size: {{x: {size[0]}, y: {size[1]}, z: {size[2]}}}
  m_Center: {{x: {center[0]}, y: {center[1]}, z: {center[2]}}}""")


def add_capsule(go, radius=0.5, height=2.0):
    go.add(136, lambda g: f"""CapsuleCollider:
{HEAD % g.id}
  m_Material: {{fileID: 0}}
  m_IncludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_ExcludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_LayerOverridePriority: 0
  m_IsTrigger: 0
  m_ProvidesContacts: 0
  m_Enabled: 1
  serializedVersion: 2
  m_Radius: {radius}
  m_Height: {height}
  m_Direction: 1
  m_Center: {{x: 0, y: 0, z: 0}}""")


def add_sphere_collider(go, radius=0.5):
    go.add(135, lambda g: f"""SphereCollider:
{HEAD % g.id}
  m_Material: {{fileID: 0}}
  m_IncludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_ExcludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_LayerOverridePriority: 0
  m_IsTrigger: 0
  m_ProvidesContacts: 0
  m_Enabled: 1
  serializedVersion: 3
  m_Radius: {radius}
  m_Center: {{x: 0, y: 0, z: 0}}""")


STATIC_BATCH = 64

# --- root objects
cam = GO("Main Camera", pos=(0, 6, -9), euler=(25, 0, 0), tag="MainCamera")
cam.add(20, lambda g: f"""Camera:
{HEAD % g.id}
  m_Enabled: 1
  serializedVersion: 2
  m_ClearFlags: 2
  m_BackGroundColor: {{r: 0.62, g: 0.82, b: 0.95, a: 0}}
  m_projectionMatrixMode: 1
  m_GateFitMode: 2
  m_FOVAxisMode: 0
  m_Iso: 200
  m_ShutterSpeed: 0.005
  m_Aperture: 16
  m_FocusDistance: 10
  m_FocalLength: 50
  m_BladeCount: 5
  m_Curvature: {{x: 2, y: 11}}
  m_BarrelClipping: 0.25
  m_Anamorphism: 0
  m_SensorSize: {{x: 36, y: 24}}
  m_LensShift: {{x: 0, y: 0}}
  m_NormalizedViewPortRect:
    serializedVersion: 2
    x: 0
    y: 0
    width: 1
    height: 1
  near clip plane: 0.3
  far clip plane: 110
  field of view: 60
  orthographic: 0
  orthographic size: 5
  m_Depth: -1
  m_CullingMask:
    serializedVersion: 2
    m_Bits: 4294967295
  m_RenderingPath: -1
  m_TargetTexture: {{fileID: 0}}
  m_TargetDisplay: 0
  m_TargetEye: 3
  m_HDR: 0
  m_AllowMSAA: 0
  m_AllowDynamicResolution: 0
  m_ForceIntoRT: 0
  m_OcclusionCulling: 1
  m_StereoConvergence: 10
  m_StereoSeparation: 0.022""")
cam.add(81, lambda g: f"""AudioListener:
{HEAD % g.id}
  m_Enabled: 1""")

sun = GO("Sun", pos=(0, 20, 0), euler=(50, -30, 0))
sun_light = sun.add(108, lambda g: f"""Light:
{HEAD % g.id}
  m_Enabled: 1
  serializedVersion: 10
  m_Type: 1
  m_Color: {{r: 1, g: 0.957, b: 0.839, a: 1}}
  m_Intensity: 1.1
  m_Range: 10
  m_SpotAngle: 30
  m_InnerSpotAngle: 21.80208
  m_CookieSize: 10
  m_Shadows:
    m_Type: 1
    m_Resolution: -1
    m_CustomResolution: -1
    m_Strength: 0.8
    m_Bias: 0.05
    m_NormalBias: 0.4
    m_NearPlane: 0.2
    m_CullingMatrixOverride:
      e00: 1
      e01: 0
      e02: 0
      e03: 0
      e10: 0
      e11: 1
      e12: 0
      e13: 0
      e20: 0
      e21: 0
      e22: 1
      e23: 0
      e30: 0
      e31: 0
      e32: 0
      e33: 1
    m_UseCullingMatrixOverride: 0
  m_Cookie: {{fileID: 0}}
  m_DrawHalo: 0
  m_Flare: {{fileID: 0}}
  m_RenderMode: 0
  m_CullingMask:
    serializedVersion: 2
    m_Bits: 4294967295
  m_RenderingLayerMask: 1
  m_Lightmapping: 4
  m_LightShadowCasterMode: 0
  m_AreaSize: {{x: 1, y: 1}}
  m_BounceIntensity: 1
  m_ColorTemperature: 6570
  m_UseColorTemperature: 0
  m_BoundingSphereOverride: {{x: 0, y: 0, z: 0, w: 0}}
  m_UseBoundingSphereOverride: 0
  m_UseViewFrustumForShadowCasterCull: 1
  m_ShadowRadius: 0
  m_ShadowAngle: 0""")

managers = GO("Managers")


def mono(script_path, fields=""):
    def body(g):
        return f"""MonoBehaviour:
{HEAD % g.id}
  m_Enabled: 1
  m_EditorHideFlags: 0
  m_Script: {{fileID: 11500000, guid: {guid(script_path)}, type: 3}}
  m_Name:
  m_EditorClassIdentifier:{fields}"""
    return body


managers.add(114, mono(SCRIPT_PERF))
managers.add(114, mono(SCRIPT_ENV, f"\n  sun: {{fileID: {sun.id + 0}}}\n  targetCamera: {{fileID: 0}}"))
# fix: sun field must reference the Light COMPONENT, camera field the Camera component
managers.extra[-1] = (114, managers.extra[-1][1],
                      mono(SCRIPT_ENV, f"\n  sun: {{fileID: {sun_light}}}\n  targetCamera: {{fileID: {cam.components[1]}}}"))

spawn = GO("PlayerSpawn", pos=(0, 0.1, 0))

env = GO("Environment")
ground = GO("Ground", pos=(0, -0.5, 0), scale=(120, 1, 120), parent=env, static=STATIC_BATCH, layer=9)
add_mesh(ground, "cube", "Ground_Grass")
add_box(ground)

rng = random.Random(42)


def far_enough(p, others, d):
    return all(math.hypot(p[0] - o[0], p[1] - o[1]) >= d for o in others)


placed = []
n_trees = 0
tries = 0
while n_trees < 16 and tries < 500:
    tries += 1
    x, z = rng.uniform(-45, 45), rng.uniform(-45, 45)
    if math.hypot(x, z) < 8 or not far_enough((x, z), placed, 7):
        continue
    placed.append((x, z))
    n_trees += 1
    h = rng.uniform(0.9, 1.4)
    tree = GO(f"Tree_{n_trees:02d}", pos=(round(x, 2), 0, round(z, 2)), parent=env, static=STATIC_BATCH)
    trunk = GO("Trunk", pos=(0, round(1.2 * h, 2), 0), scale=(0.6, round(1.2 * h, 2), 0.6), parent=tree, static=STATIC_BATCH)
    add_mesh(trunk, "cylinder", "Trunk_Brown")
    add_capsule(trunk, 0.5, 2.0)
    crown = GO("Foliage", pos=(0, round(2.9 * h + 0.6, 2), 0), scale=(3.2, round(2.8 * h, 2), 3.2), parent=tree, static=STATIC_BATCH)
    add_mesh(crown, "sphere", "Foliage_Green")

n_rocks = 0
tries = 0
while n_rocks < 8 and tries < 500:
    tries += 1
    x, z = rng.uniform(-40, 40), rng.uniform(-40, 40)
    if math.hypot(x, z) < 6 or not far_enough((x, z), placed, 4):
        continue
    placed.append((x, z))
    n_rocks += 1
    s = rng.uniform(0.8, 1.6)
    rock = GO(f"Rock_{n_rocks:02d}", pos=(round(x, 2), 0.25, round(z, 2)), euler=(0, round(rng.uniform(0, 180), 1), 0),
              scale=(round(1.4 * s, 2), round(0.8 * s, 2), round(1.1 * s, 2)), parent=env, static=STATIC_BATCH)
    add_mesh(rock, "sphere", "Rock_Gray")
    add_sphere_collider(rock, 0.5)

all_go = []


def collect(g):
    all_go.append(g)
    for c in g.children:
        collect(c)


roots = [cam, sun, managers, spawn, env]
for r in roots:
    collect(r)
for g in all_go:
    g.emit()

scene = ["%YAML 1.1", "%TAG !u! tag:unity3d.com,2011:"]
scene.append(f"""--- !u!29 &1
OcclusionCullingSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 2
  m_OcclusionBakeSettings:
    smallestOccluder: 5
    smallestHole: 0.25
    backfaceThreshold: 100
  m_SceneGUID: 00000000000000000000000000000000
  m_OcclusionCullingData: {{fileID: 0}}
--- !u!104 &2
RenderSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 10
  m_Fog: 1
  m_FogColor: {{r: 0.78, g: 0.9, b: 0.96, a: 1}}
  m_FogMode: 1
  m_FogDensity: 0.01
  m_LinearFogStart: 35
  m_LinearFogEnd: 95
  m_AmbientSkyColor: {{r: 0.7, g: 0.85, b: 1, a: 1}}
  m_AmbientEquatorColor: {{r: 0.62, g: 0.72, b: 0.58, a: 1}}
  m_AmbientGroundColor: {{r: 0.38, g: 0.4, b: 0.3, a: 1}}
  m_AmbientIntensity: 1
  m_AmbientMode: 1
  m_SubtractiveShadowColor: {{r: 0.42, g: 0.478, b: 0.627, a: 1}}
  m_SkyboxMaterial: {{fileID: 0}}
  m_HaloStrength: 0.5
  m_FlareStrength: 1
  m_FlareFadeSpeed: 3
  m_HaloTexture: {{fileID: 0}}
  m_SpotCookie: {{fileID: 10001, guid: 0000000000000000e000000000000000, type: 0}}
  m_DefaultReflectionMode: 0
  m_DefaultReflectionResolution: 128
  m_ReflectionBounces: 1
  m_ReflectionIntensity: 1
  m_CustomReflection: {{fileID: 0}}
  m_Sun: {{fileID: {sun_light}}}
  m_UseRadianceAmbientProbe: 0
--- !u!157 &3
LightmapSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 12
  m_GIWorkflowMode: 1
  m_GISettings:
    serializedVersion: 2
    m_BounceScale: 1
    m_IndirectOutputScale: 1
    m_AlbedoBoost: 1
    m_EnvironmentLightingMode: 0
    m_EnableBakedLightmaps: 0
    m_EnableRealtimeLightmaps: 0
  m_LightmapEditorSettings:
    serializedVersion: 12
    m_Resolution: 2
    m_BakeResolution: 40
    m_AtlasSize: 1024
    m_AO: 0
    m_AOMaxDistance: 1
    m_CompAOExponent: 1
    m_CompAOExponentDirect: 0
    m_ExtractAmbientOcclusion: 0
    m_Padding: 2
    m_LightmapParameters: {{fileID: 0}}
    m_LightmapsBakeMode: 1
    m_TextureCompression: 1
    m_FinalGather: 0
    m_FinalGatherFiltering: 1
    m_FinalGatherRayCount: 256
    m_ReflectionCompression: 2
    m_MixedBakeMode: 2
    m_BakeBackend: 1
    m_PVRSampling: 1
    m_PVRDirectSampleCount: 32
    m_PVRSampleCount: 512
    m_PVRBounces: 2
    m_PVREnvironmentSampleCount: 256
    m_PVREnvironmentReferencePointCount: 2048
    m_PVRFilteringMode: 1
    m_PVRDenoiserTypeDirect: 1
    m_PVRDenoiserTypeIndirect: 1
    m_PVRDenoiserTypeAO: 1
    m_PVRFilterTypeDirect: 0
    m_PVRFilterTypeIndirect: 0
    m_PVRFilterTypeAO: 0
    m_PVREnvironmentMIS: 1
    m_PVRCulling: 1
    m_PVRFilteringGaussRadiusDirect: 1
    m_PVRFilteringGaussRadiusIndirect: 5
    m_PVRFilteringGaussRadiusAO: 2
    m_PVRFilteringAtrousPositionSigmaDirect: 0.5
    m_PVRFilteringAtrousPositionSigmaIndirect: 2
    m_PVRFilteringAtrousPositionSigmaAO: 1
    m_ExportTrainingData: 0
    m_TrainingDataDestination: TrainingData
    m_LightProbeSampleCountMultiplier: 4
  m_LightingDataAsset: {{fileID: 0}}
  m_LightingSettings: {{fileID: 0}}
--- !u!196 &4
NavMeshSettings:
  serializedVersion: 2
  m_ObjectHideFlags: 0
  m_BuildSettings:
    serializedVersion: 3
    agentTypeID: 0
    agentRadius: 0.5
    agentHeight: 2
    agentSlope: 45
    agentClimb: 0.4
    ledgeDropHeight: 0
    maxJumpAcrossDistance: 0
    minRegionArea: 2
    manualCellSize: 0
    cellSize: 0.16666667
    manualTileSize: 0
    tileSize: 256
    buildHeightMesh: 0
    maxJobWorkers: 0
    preserveTilesOutsideBounds: 0
    debug:
      m_Flags: 0
  m_NavMeshData: {{fileID: 0}}""".rstrip())
for class_id, fid, body in docs:
    scene.append(f"--- !u!{class_id} &{fid}\n{body}")
root_ids = "\n".join(f"  - {{fileID: {r.tr}}}" for r in roots)
scene.append(f"--- !u!1660057539 &9223372036854775807\nSceneRoots:\n  m_ObjectHideFlags: 0\n  m_Roots:\n{root_ids}")
write("Assets/Scenes/ForestWorld.unity", "\n".join(scene) + "\n")

# --------------------------------------------------------------------------- project settings
write("ProjectSettings/ProjectVersion.txt", "m_EditorVersion: 6000.0.23f1\n")

write("ProjectSettings/ProjectSettings.asset", f"""%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!129 &1
PlayerSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 26
  productGUID: {guid('productGUID')}
  companyName: TinyWorld Studio
  productName: Tiny World Adventure
  defaultScreenOrientation: 4
  targetDevice: 2
  accelerometerFrequency: 60
  bundleVersion: 0.1.0
  preloadedAssets: []
  colorSpace: 0
  m_ActiveColorSpace: 0
  allowedAutorotateToPortrait: 0
  allowedAutorotateToPortraitUpsideDown: 0
  allowedAutorotateToLandscapeRight: 1
  allowedAutorotateToLandscapeLeft: 1
  useOSAutorotation: 1
  androidStartInFullscreen: 1
  androidRenderOutsideSafeArea: 1
  AndroidMinSdkVersion: 24
  AndroidTargetSdkVersion: 0
  AndroidBundleVersionCode: 1
  AndroidTargetArchitectures: 3
  applicationIdentifier:
    Android: com.tinyworld.adventure
  scriptingBackend:
    Android: 1
  gpuSkinning: 1
  mtRendering: 1
  stripEngineCode: 1
""")

write("ProjectSettings/EditorBuildSettings.asset", f"""%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!1045 &1
EditorBuildSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 2
  m_Scenes:
  - enabled: 1
    path: Assets/Scenes/ForestWorld.unity
    guid: {guid('Assets/Scenes/ForestWorld.unity')}
  m_configObjects: {{}}
""")

write("ProjectSettings/TimeManager.asset", """%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!5 &1
TimeManager:
  m_ObjectHideFlags: 0
  Fixed Timestep: 0.033333335
  Maximum Allowed Timestep: 0.1
  m_TimeScale: 1
  Maximum Particle Timestep: 0.03
""")

write("ProjectSettings/DynamicsManager.asset", """%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!55 &1
PhysicsManager:
  m_ObjectHideFlags: 0
  serializedVersion: 13
  m_Gravity: {x: 0, y: -9.81, z: 0}
  m_DefaultMaterial: {fileID: 0}
  m_BounceThreshold: 2
  m_DefaultMaxDepenetrationVelocity: 10
  m_SleepThreshold: 0.005
  m_DefaultContactOffset: 0.01
  m_DefaultSolverIterations: 4
  m_DefaultSolverVelocityIterations: 1
  m_QueriesHitBackfaces: 0
  m_QueriesHitTriggers: 1
  m_EnableAdaptiveForce: 0
  m_ClothInterCollisionDistance: 0.1
  m_ClothInterCollisionStiffness: 0.2
  m_ContactsGeneration: 1
  m_AutoSimulation: 1
  m_AutoSyncTransforms: 0
  m_ReuseCollisionCallbacks: 1
""")

layers = ["Default", "TransparentFX", "Ignore Raycast", "", "Water", "UI", "", "",
          "Player", "Ground", "Animal", "Collectible", "Interactable"]
layers += [""] * (32 - len(layers))
layer_lines = "\n".join(f"  - {l}".rstrip() + (" " if not l else "") for l in layers)
write("ProjectSettings/TagManager.asset", f"""%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!78 &1
TagManager:
  serializedVersion: 2
  tags:
  - Animal
  - Collectible
  layers:
{layer_lines}
  m_SortingLayers:
  - name: Default
    uniqueID: 0
    locked: 0
""")

write("ProjectSettings/QualitySettings.asset", """%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!47 &1
QualitySettings:
  m_ObjectHideFlags: 0
  serializedVersion: 5
  m_CurrentQuality: 0
  m_QualitySettings:
  - serializedVersion: 3
    name: Mobile
    pixelLightCount: 1
    shadows: 1
    shadowResolution: 0
    shadowProjection: 1
    shadowCascades: 1
    shadowDistance: 25
    shadowNearPlaneOffset: 3
    shadowCascade2Split: 0.33333334
    shadowCascade4Split: {x: 0.06666667, y: 0.2, z: 0.46666667}
    shadowmaskMode: 0
    skinWeights: 2
    globalTextureMipmapLimit: 0
    anisotropicTextures: 0
    antiAliasing: 0
    softParticles: 0
    softVegetation: 0
    realtimeReflectionProbes: 0
    billboardsFaceCameraPosition: 0
    vSyncCount: 0
    lodBias: 0.8
    maximumLODLevel: 0
    streamingMipmapsActive: 0
    particleRaycastBudget: 16
    asyncUploadTimeSlice: 2
    asyncUploadBufferSize: 16
    asyncUploadPersistentBuffer: 1
    resolutionScalingFixedDPIFactor: 1
    excludedTargetPlatforms: []
  m_TextureMipmapLimitGroupNames: []
  m_PerPlatformDefaultQuality:
    Android: 0
    Standalone: 0
""")

write("Packages/manifest.json", """{
  "dependencies": {
    "com.unity.ide.rider": "3.0.31",
    "com.unity.ide.visualstudio": "2.0.22",
    "com.unity.test-framework": "1.4.5",
    "com.unity.ugui": "2.0.0",
    "com.unity.modules.ai": "1.0.0",
    "com.unity.modules.androidjni": "1.0.0",
    "com.unity.modules.animation": "1.0.0",
    "com.unity.modules.audio": "1.0.0",
    "com.unity.modules.imgui": "1.0.0",
    "com.unity.modules.jsonserialize": "1.0.0",
    "com.unity.modules.particlesystem": "1.0.0",
    "com.unity.modules.physics": "1.0.0",
    "com.unity.modules.ui": "1.0.0"
  }
}
""")

write(".gitignore", """# Unity generated
/[Ll]ibrary/
/[Tt]emp/
/[Oo]bj/
/[Bb]uild/
/[Bb]uilds/
/[Ll]ogs/
/[Uu]ser[Ss]ettings/
/[Mm]emoryCaptures/
/[Rr]ecordings/
# IDE
.vs/
.idea/
*.csproj
*.sln
*.suo
*.user
*.pidb.meta
# Build outputs
*.apk
*.aab
*.unitypackage
# OS
.DS_Store
Thumbs.db
""")

write(".gitattributes", """* text=auto
*.cs text eol=lf
*.shader text eol=lf
*.unity merge=unityyamlmerge eol=lf
*.mat merge=unityyamlmerge eol=lf
*.prefab merge=unityyamlmerge eol=lf
*.asset merge=unityyamlmerge eol=lf
*.meta text eol=lf
*.fbx binary
*.png binary
*.jpg binary
*.wav binary
*.ogg binary
""")

# --------------------------------------------------------------------------- .meta files
MONO_META = """fileFormatVersion: 2
guid: {g}
MonoImporter:
  externalObjects: {{}}
  serializedVersion: 2
  defaultReferences: []
  executionOrder: 0
  icon: {{instanceID: 0}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""
FOLDER_META = """fileFormatVersion: 2
guid: {g}
folderAsset: yes
DefaultImporter:
  externalObjects: {{}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""
DEFAULT_META = """fileFormatVersion: 2
guid: {g}
DefaultImporter:
  externalObjects: {{}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""
MAT_META = """fileFormatVersion: 2
guid: {g}
NativeFormatImporter:
  externalObjects: {{}}
  mainObjectFileID: 2100000
  userData:
  assetBundleName:
  assetBundleVariant:
"""
SHADER_META = """fileFormatVersion: 2
guid: {g}
ShaderImporter:
  externalObjects: {{}}
  defaultTextures: []
  nonModifiableTextures: []
  preprocessorOverride: 0
  userData:
  assetBundleName:
  assetBundleVariant:
"""
TEXT_META = """fileFormatVersion: 2
guid: {g}
TextScriptImporter:
  externalObjects: {{}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""

for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, "Assets")):
    rel_dir = os.path.relpath(dirpath, ROOT).replace(os.sep, "/")
    if rel_dir != "Assets":
        p = rel_dir
        write(p + ".meta", FOLDER_META.format(g=guid(p)))
    for fn in filenames:
        if fn.endswith(".meta") or fn.startswith("."):
            continue
        p = f"{rel_dir}/{fn}"
        g = guid(p)
        if fn.endswith(".cs"):
            t = MONO_META
        elif fn.endswith(".mat"):
            t = MAT_META
        elif fn.endswith(".shader"):
            t = SHADER_META
        elif fn.endswith(".md") or fn.endswith(".txt"):
            t = TEXT_META
        else:
            t = DEFAULT_META
        write(p + ".meta", t.format(g=g))

print("generated; scene objects:", len(all_go), "yaml docs:", len(docs) + 5)
