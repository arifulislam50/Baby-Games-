import os, re, sys, json, yaml
ROOT = sys.argv[1]
errors, notes = [], []

def unity_docs(path):
    text = open(path).read()
    parts = re.split(r'^--- !u!(\d+) &(\d+)[^\n]*\n', text, flags=re.M)
    docs = []
    for i in range(1, len(parts), 3):
        docs.append((int(parts[i]), int(parts[i+1]), yaml.safe_load(parts[i+2])))
    return docs

# 1. every asset has a meta, every meta has an asset, GUIDs unique
guids = {}
for dp, dn, fn in os.walk(os.path.join(ROOT, "Assets")):
    for f in fn + dn:
        full = os.path.join(dp, f)
        if f.startswith("."): continue
        if f.endswith(".meta"):
            base = full[:-5]
            if not os.path.exists(base): errors.append("orphan meta: " + full)
            m = yaml.safe_load(open(full))
            g = m.get("guid")
            if not g or len(g) != 32: errors.append("bad guid: " + full)
            if g in guids: errors.append(f"duplicate guid {g}: {full} / {guids[g]}")
            guids[g] = full
        else:
            if not os.path.exists(full + ".meta"): errors.append("missing meta: " + full)

# 2. YAML parses
yaml_files = []
for dp, dn, fn in os.walk(ROOT):
    for f in fn:
        if f.endswith((".unity", ".mat", ".asset")):
            yaml_files.append(os.path.join(dp, f))
parsed = {}
for p in yaml_files:
    try:
        parsed[p] = unity_docs(p)
    except Exception as e:
        errors.append(f"YAML parse failed {p}: {e}")
json.load(open(os.path.join(ROOT, "Packages/manifest.json")))

# 3. scene integrity
scene = os.path.join(ROOT, "Assets/Scenes/ForestWorld.unity")
docs = parsed[scene]
ids = {fid: (cid, body) for cid, fid, body in docs}
if len(ids) != len(docs): errors.append("duplicate fileIDs in scene")
text = open(scene).read()
for m in re.finditer(r'\{fileID: (-?\d+)(?:, guid: ([0-9a-f]{32}), type: (\d))?\}', text):
    fid, g, t = int(m.group(1)), m.group(2), m.group(3)
    if g is None:
        if fid != 0 and fid not in ids: errors.append(f"dangling fileID {fid} in scene")
    elif g != "0"*16+"e000000000000000" and g != "0000000000000000f000000000000000":
        if g not in guids: errors.append(f"scene/material references unknown guid {g}")
# GameObject <-> component consistency
n_go = n_tr = 0
for cid, fid, body in docs:
    if cid == 1:
        n_go += 1
        for c in body["GameObject"]["m_Component"]:
            cf = c["component"]["fileID"]
            if cf not in ids: errors.append(f"GO {body['GameObject']['m_Name']} lists missing component {cf}")
            else:
                owner = list(ids[cf][1].values())[0].get("m_GameObject", {}).get("fileID")
                if owner != fid: errors.append(f"component {cf} owner mismatch")
    if cid == 4:
        n_tr += 1
        t = body["Transform"]
        for ch in t["m_Children"] or []:
            cf = ch["fileID"]
            if ids[cf][1]["Transform"]["m_Father"]["fileID"] != fid: errors.append(f"child {cf} father mismatch")
roots = [r["fileID"] for r in [d for d in docs if d[0]==1660057539][0][2]["SceneRoots"]["m_Roots"]]
for r in roots:
    if ids[r][1]["Transform"]["m_Father"]["fileID"] != 0: errors.append("root has father")
if n_go != n_tr: errors.append("GameObject/Transform count mismatch")
# scripts referenced by scene exist and name matches class file
for cid, fid, body in docs:
    if cid == 114:
        g = body["MonoBehaviour"]["m_Script"]["guid"]
        meta = guids.get(g)
        if not meta: errors.append("MonoBehaviour script guid unknown")
        else:
            cs = meta[:-5]
            src = open(cs).read()
            for fld in body["MonoBehaviour"]:
                if fld.startswith("m_"): continue
                if not re.search(r'\b' + fld + r'\b', src): errors.append(f"serialized field '{fld}' not in {os.path.basename(cs)}")
# render settings sun is a Light component
sun = [d for d in docs if d[0]==104][0][2]["RenderSettings"]["m_Sun"]["fileID"]
if "Light" not in ids[sun][1]: errors.append("RenderSettings.m_Sun is not a Light")
# materials reference the shader guid
shader_guid = yaml.safe_load(open(os.path.join(ROOT,"Assets/Materials/Shaders/LowPolyLit.shader.meta")))["guid"]
for p, d in parsed.items():
    if p.endswith(".mat") and d[0][2]["Material"]["m_Shader"]["guid"] != shader_guid: errors.append("material shader guid wrong: " + p)
# build settings points at the scene
bs = parsed[os.path.join(ROOT,"ProjectSettings/EditorBuildSettings.asset")][0][2]["EditorBuildSettings"]["m_Scenes"][0]
scene_guid = yaml.safe_load(open(scene+".meta"))["guid"]
if bs["guid"] != scene_guid: errors.append("EditorBuildSettings scene guid mismatch")

# 4. required folders
for f in ["Scripts/Player","Scripts/Camera","Scripts/Missions","Scripts/Animals","Scripts/UI","Scripts/Managers","Characters","Animations","Environment","Materials","Prefabs","Scenes","Audio","UI"]:
    if not os.path.isdir(os.path.join(ROOT,"Assets",f)): errors.append("missing folder " + f)

print(f"scene: {n_go} GameObjects, {len(docs)} documents, {len(roots)} roots; {len(guids)} metas; yaml files parsed: {len(parsed)}")
print("ERRORS:" if errors else "ALL CHECKS PASSED")
for e in errors: print(" -", e)
sys.exit(1 if errors else 0)
